using System.Collections.Generic;
using Prism.Windows.Mvvm;
using Windows.UI.Xaml.Navigation;
using Windows.UI.Xaml.Controls;

namespace HelloWorld.Views
{
    public sealed partial class UserInputPage : Page
    {
        public UserInputPage()
        {
            InitializeComponent();
        }
    }
}
