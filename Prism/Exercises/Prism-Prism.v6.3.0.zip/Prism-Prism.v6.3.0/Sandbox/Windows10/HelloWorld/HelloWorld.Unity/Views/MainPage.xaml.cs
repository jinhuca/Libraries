using Prism.Windows.Mvvm;
using Windows.UI.Xaml.Controls;

namespace HelloWorld.Views
{
    /// <summary>
    /// A basic page that provides characteristics common to most applications.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            InitializeComponent();
        }
    }
}
