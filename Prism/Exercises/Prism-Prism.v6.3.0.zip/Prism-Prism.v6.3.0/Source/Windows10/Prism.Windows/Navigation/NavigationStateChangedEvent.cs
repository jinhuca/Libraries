﻿using Prism.Events;

namespace Prism.Windows.Navigation
{
    public class NavigationStateChangedEvent : PubSubEvent<NavigationStateChangedEventArgs>
    {
    }
}
