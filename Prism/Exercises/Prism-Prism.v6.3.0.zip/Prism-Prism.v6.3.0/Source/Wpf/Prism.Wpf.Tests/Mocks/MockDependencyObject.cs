

using System.Windows;

namespace Prism.Wpf.Tests.Mocks
{
    public class MockDependencyObject : DependencyObject
    {
    }
}