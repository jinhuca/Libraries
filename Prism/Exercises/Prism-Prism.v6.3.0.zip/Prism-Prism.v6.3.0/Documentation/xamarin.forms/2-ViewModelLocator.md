﻿# Using the ViewModelLocator

Prism for XF depends on the use of VML

namespace

attached property

naming convention

change naming convention

changing resolver

custom registrations

maybe link to primary ViewModelLocator topic so we don't repeat content, and only include the namesapce and attached property info in this topic?