﻿namespace ConfigModuleEditor.Models
{
    public class ProjectModuleInfo
    {
        public string AssemblyFile { get; set; }
        public string ModuleType { get; set; }
        public string ModuleName { get; set; }
    }
}
