﻿using Xamarin.Forms;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : CarouselPage
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}
