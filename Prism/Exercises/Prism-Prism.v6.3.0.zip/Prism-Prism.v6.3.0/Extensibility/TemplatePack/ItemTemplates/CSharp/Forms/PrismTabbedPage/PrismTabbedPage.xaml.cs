﻿using Xamarin.Forms;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : TabbedPage
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}
