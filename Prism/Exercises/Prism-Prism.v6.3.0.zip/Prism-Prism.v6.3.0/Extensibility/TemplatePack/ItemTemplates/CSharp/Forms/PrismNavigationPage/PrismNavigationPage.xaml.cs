﻿using Xamarin.Forms;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : NavigationPage
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}
