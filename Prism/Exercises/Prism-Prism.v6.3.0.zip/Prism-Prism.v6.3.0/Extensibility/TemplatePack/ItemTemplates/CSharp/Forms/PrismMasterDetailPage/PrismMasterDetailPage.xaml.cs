﻿using Xamarin.Forms;

namespace $rootnamespace$
{
    public partial class $safeitemname$ : MasterDetailPage
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}