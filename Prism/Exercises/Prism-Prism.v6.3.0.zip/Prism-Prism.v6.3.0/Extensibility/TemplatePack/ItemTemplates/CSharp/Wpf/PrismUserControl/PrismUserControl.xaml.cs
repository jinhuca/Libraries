﻿using System.Windows.Controls;

namespace $rootnamespace$
{
    /// <summary>
    /// Interaction logic for $safeitemname$
    /// </summary>
    public partial class $safeitemname$ : UserControl
    {
        public $safeitemname$()
        {
            InitializeComponent();
        }
    }
}
