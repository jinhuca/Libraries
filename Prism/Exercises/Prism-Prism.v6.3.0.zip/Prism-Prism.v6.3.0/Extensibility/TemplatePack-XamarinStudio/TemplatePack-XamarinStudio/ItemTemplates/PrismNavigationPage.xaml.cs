﻿using Xamarin.Forms;

namespace ${Namespace}.Views
{
	public partial class ${Name} : NavigationPage
	{
		public ${Name} ()
		{
			InitializeComponent ();
		}
	}
}

