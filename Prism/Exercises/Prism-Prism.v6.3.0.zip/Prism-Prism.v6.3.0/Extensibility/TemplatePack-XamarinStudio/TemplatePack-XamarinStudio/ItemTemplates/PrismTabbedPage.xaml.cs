﻿using Xamarin.Forms;

namespace ${Namespace}.Views
{
	public partial class ${Name} : TabbedPage
	{
		public ${Name} ()
		{
			InitializeComponent ();
		}
	}
}

