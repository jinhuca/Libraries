﻿using Xamarin.Forms;

namespace ${Namespace}.Views
{
	public partial class ${Name} : MasterDetailPage
	{
		public ${Name} ()
		{
			InitializeComponent ();
		}
	}
}

