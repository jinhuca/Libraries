﻿using Xamarin.Forms;

namespace ${Namespace}.Views
{
	public partial class ${Name} : ContentPage
	{
		public ${Name} ()
		{
			InitializeComponent ();
		}
	}
}

