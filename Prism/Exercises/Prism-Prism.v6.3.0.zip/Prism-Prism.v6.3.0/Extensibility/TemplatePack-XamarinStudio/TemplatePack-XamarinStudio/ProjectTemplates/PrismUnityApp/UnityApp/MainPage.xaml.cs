﻿using Xamarin.Forms;

namespace ${Namespace}.Views
{
	public partial class MainPage : ContentPage
	{
		public MainPage ()
		{
			InitializeComponent ();
		}
	}
}

