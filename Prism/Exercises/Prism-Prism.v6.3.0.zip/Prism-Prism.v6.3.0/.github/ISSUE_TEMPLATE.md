*Use GitHub issues for __bugs in Prism and feature requests only__. If you have a question how to implement something using Prism or a bug in your app that might be related to Prism, please post your question on [StackOverflow](http://stackoverflow.com/tags/prism) (which we monitor as well).*

Please provide as much detail as possible (and feel free to remove unused properties):

### Package info

- Platform:
- Prism version:
- Xamarin version (if applicable):
- Windows 10 SDK version (if applicable):
- Other version info:

### Repro steps

Please describe the issue/request in detail.