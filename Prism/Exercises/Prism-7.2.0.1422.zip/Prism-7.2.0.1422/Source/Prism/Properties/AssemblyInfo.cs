﻿using System;

[assembly: CLSCompliant(true)]
