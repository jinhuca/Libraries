﻿namespace Prism.Tests.Common.Mocks
{
    internal enum MockEnum
    {
        None = 0,
        Foo = 1,
        Bar = 2,
        Fizz = 3,
        SomethingElse = 99
    }
}
