

using Prism.Regions;

namespace Prism.Wpf.Tests.Mocks
{
    [ViewSortHint("01")]
    internal class MockSortableView1
    {
    }

    [ViewSortHint("02")]
    internal class MockSortableView2
    {
    }

    [ViewSortHint("03")]
    internal class MockSortableView3
    {
    }
}
