﻿using System.Windows;

namespace Prism.Wpf.Tests.Mocks.Views
{
    public class Mock : FrameworkElement
    {
    }
}
