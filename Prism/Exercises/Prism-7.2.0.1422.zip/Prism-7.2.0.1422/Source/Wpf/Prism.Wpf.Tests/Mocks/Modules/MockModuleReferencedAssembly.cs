

namespace Prism.Wpf.Tests.Mocks.Modules
{
    public class MockReferencedModule
    {
    }
}