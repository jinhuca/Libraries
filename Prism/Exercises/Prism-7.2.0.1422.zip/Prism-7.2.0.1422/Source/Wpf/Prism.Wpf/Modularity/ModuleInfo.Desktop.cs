

using System;

namespace Prism.Modularity
{
    [Serializable]
    public partial class ModuleInfo
    {
    }
}
