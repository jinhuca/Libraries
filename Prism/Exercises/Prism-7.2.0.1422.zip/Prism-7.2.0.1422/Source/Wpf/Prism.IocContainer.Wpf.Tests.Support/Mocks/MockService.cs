


namespace Prism.IocContainer.Wpf.Tests.Support.Mocks
{
    public class MockService : IService
    {
    }

    public interface IService { }
}