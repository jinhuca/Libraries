﻿using System.Windows;

namespace Prism.IocContainer.Wpf.Tests.Support.Mocks.Views
{
    public class MockView : FrameworkElement
    {
    }
}
