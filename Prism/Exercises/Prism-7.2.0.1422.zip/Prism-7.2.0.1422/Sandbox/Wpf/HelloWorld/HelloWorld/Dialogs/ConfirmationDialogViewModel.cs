﻿namespace HelloWorld.Dialogs
{
    public class ConfirmationDialogViewModel : NotificationDialogViewModel
    {
        public ConfirmationDialogViewModel()
        {
            Title = "Confirmation";
        }
    }
}
