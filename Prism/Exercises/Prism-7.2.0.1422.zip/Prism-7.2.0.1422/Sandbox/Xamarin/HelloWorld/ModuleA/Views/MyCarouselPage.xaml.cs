﻿using Xamarin.Forms;

namespace ModuleA.Views
{
    public partial class MyCarouselPage : CarouselPage
    {
        public MyCarouselPage()
        {
            InitializeComponent();
        }
    }
}
