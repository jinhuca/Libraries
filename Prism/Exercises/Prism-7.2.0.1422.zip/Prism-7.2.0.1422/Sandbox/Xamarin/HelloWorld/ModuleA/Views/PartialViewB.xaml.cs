﻿using Xamarin.Forms.Xaml;

namespace ModuleA.Views
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class PartialViewB
    {
        public PartialViewB ()
        {
            InitializeComponent ();
        }
    }
}