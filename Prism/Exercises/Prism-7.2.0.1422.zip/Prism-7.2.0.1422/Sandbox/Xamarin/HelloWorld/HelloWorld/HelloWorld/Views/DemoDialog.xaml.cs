﻿using Xamarin.Forms;

namespace HelloWorld.Views
{
    public partial class DemoDialog
    {
        public DemoDialog()
        {
            InitializeComponent();
        }
    }
}
