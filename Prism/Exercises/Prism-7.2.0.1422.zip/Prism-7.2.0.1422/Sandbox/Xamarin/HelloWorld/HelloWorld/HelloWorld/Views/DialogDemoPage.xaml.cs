﻿using Xamarin.Forms;

namespace HelloWorld.Views
{
    public partial class DialogDemoPage : ContentPage
    {
        public DialogDemoPage()
        {
            InitializeComponent();
        }
    }
}
