﻿using Xamarin.Forms;

namespace HelloWorld.Views
{
    public partial class UserAlert
    {
        public UserAlert()
        {
            InitializeComponent();
        }
    }
}
