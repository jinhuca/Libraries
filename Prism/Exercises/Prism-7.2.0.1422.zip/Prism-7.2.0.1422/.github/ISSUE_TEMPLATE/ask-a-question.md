---
name: Ask a Question
about: STOP!!!! This issue will be closed. All questions should be asked on StackOverflow!
title: STOP!!! This issue will be closed!
labels: invalid
assignees: ''

---

The Prism team does NOT answer questions on GitHub. 

All "How do I", "Why doesn't this work", "Can you help me", or any other questions you may have, should be posted on StackOverflow or asked by Prism Patrons in Prism Slack.

Ignoring this and asking anyway will simply result in your issue being closed and your question being ignored by the Prism team.

To ask a question select the appropriate link:

- WPF: https://stackoverflow.com/questions/ask?tags=prism&tags=wpf
- Xamarin.Forms: https://stackoverflow.com/questions/ask?tags=prism&tags=xamarin.forms
