---
name: Bug report
about: Create a report to help us improve
title: "[Bug] "
labels: ''
assignees: ''

---

### Description

<!-- REQUIRED -->
<!-- Issues reporting a bug, but lacking a Reproduction will be closed!
     Please ask questions on StackOverflow or on Slack. Issues opened
     that are questions will be closed without comment.  -->

### Steps to Reproduce

1. 
2. 
3. 

### Expected Behavior

### Actual Behavior

### Basic Information

- Version with issue:
- Last known good version:
- Xamarin.Forms version:
- IDE:

### Screenshots

<!-- If the issue is a visual issue, please include screenshots showing the problem if possible -->

### Reproduction Link

<!-- REQUIRED - Please upload or provide a link to a reproduction case. If no reproduction sample is included, this issue may be closed or ignored until a sample has been provided -->
